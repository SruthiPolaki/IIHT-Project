import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-one',
  templateUrl: './banner-one.component.html',
  styleUrls: ['./banner-one.component.css']
})
export class BannerOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
